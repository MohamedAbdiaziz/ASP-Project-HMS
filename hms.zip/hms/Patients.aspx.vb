﻿Imports System.Data.SqlClient
Imports System.Data

Public Class Patients
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Adm\Hospital\Hospital\Hospital\App_Data\Hms.mdf;Integrated Security=True")
    Dim cmd As New SqlCommand

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cmd.Connection = conn
        cmd.CommandText = CommandType.Text
        cmd.CommandText = "select * from patients"
        conn.Open()
        cmd.ExecuteNonQuery()

        conn.Close()
    End Sub

    Protected Sub patient_table_SelectedIndexChanged(sender As Object, e As EventArgs) Handles patient_table.SelectedIndexChanged

    End Sub
End Class