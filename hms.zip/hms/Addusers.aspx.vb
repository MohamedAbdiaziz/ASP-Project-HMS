﻿Imports System.Data.SqlClient
Imports System.Data

Public Class Addusers
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Adm\Hospital\Hospital\Hospital\App_Data\Hms.mdf;Integrated Security=True")
    Dim cmd As New SqlCommand


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub save_Click(sender As Object, e As EventArgs) Handles save.Click
        cmd.Connection = conn
        cmd.CommandText = CommandType.Text
        cmd.CommandText = "insert into users(name, username,role, password, created_at) values('" + name.Text + "', '" + username.Text + "','Admin', '" + password.Text + "', '" + reg_date.Text + "')"
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        MsgBox("Data inserted Successfully")
        name.Text = ""
        username.Text = ""
        password.Text = ""
        reg_date.Text = ""
        Response.Redirect("Users.aspx")
    End Sub
End Class