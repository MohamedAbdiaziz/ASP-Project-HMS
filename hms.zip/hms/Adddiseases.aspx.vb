﻿Imports System.Data.SqlClient
Imports System.Data

Public Class Adddiseases
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Adm\Hospital\Hospital\Hospital\App_Data\Hms.mdf;Integrated Security=True")
    Dim cmd As New SqlCommand


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub save_Click(sender As Object, e As EventArgs) Handles save.Click
        cmd.Connection = conn
        cmd.CommandText = CommandType.Text
        cmd.CommandText = "insert into diseases values('" + diseases_name.Text + "', '" + reg_date.Text + "')"
        conn.Open()
        cmd.ExecuteNonQuery()
        MsgBox("Data inserted Successfully")
        conn.Close()
        diseases_name.Text = ""
        reg_date.Text = ""
    End Sub
End Class