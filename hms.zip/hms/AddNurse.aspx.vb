﻿Imports System.Data.SqlClient

Public Class AddNurse
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Adm\Hospital\Hospital\Hospital\App_Data\Hms.mdf;Integrated Security=True")
    Dim cmd As New SqlCommand
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub save_Click(sender As Object, e As EventArgs) Handles save.Click
        cmd.Connection = conn
        cmd.CommandText = CommandType.Text
        cmd.CommandText = "insert into Nurse(FirstName,LastName,DateOfBirth,Gender,ContactNumber,Email,Address,Department,ShiftStartTime,ShiftEndTime) values('" + nurse_fname.Text + "','" + nurse_lname.Text + "','" + age.Text + "','" + gender.Text + "','" + Tell.Text + "','" + email.Text + "', '" + address.Text + "','" + DP.Text + "','" + shiftstart.Text + "','" + shiftend.Text + "')"
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        MsgBox("Data inserted Successfully")
        Response.Redirect("Nurse.aspx")
    End Sub
End Class