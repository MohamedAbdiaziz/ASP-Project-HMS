﻿Imports System.Data.SqlClient

Public Class AddDoctor
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Adm\Hospital\Hospital\Hospital\App_Data\Hms.mdf;Integrated Security=True")
    Dim cmd As New SqlCommand
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub save_Click(sender As Object, e As EventArgs) Handles save.Click
        cmd.Connection = conn
        cmd.CommandText = CommandType.Text
        cmd.CommandText = "INSERT INTO doctors (name, tellno, address, email, gender, specialty, created_at, updated_at) VALUES ('" + doctor_name.Text + "', '" + tellno.Text + "', '" + address.Text + "', '" + email.Text + "', '" + gender.Text + "', N'" + specialty.Text + "', '" + reg_date.Text + "', NULL)"
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        MsgBox("Data inserted Successfully")
        doctor_name.Text = ""
        tellno.Text = ""
        address.Text = ""
        email.Text = ""
        specialty.Text = ""

        Response.Redirect("Doctor.aspx")
    End Sub
End Class