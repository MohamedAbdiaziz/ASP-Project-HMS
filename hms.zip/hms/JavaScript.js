﻿$(function () {
    var url = window.location;
    // for single sidebar menu
    $('ul.nav-sidebar a').filter(function () {
        return this.href == url;
    }).addClass('active');

    // for sidebar menu and treeview
    $('ul.nav-treeview a').filter(function () {
        return this.href == url;
    }).parentsUntil(".nav-sidebar > .nav-treeview")
        .css({
            'display': 'block'
        }).addClass('menu-open').prev('a').addClass('active');
});
//Collapsed Sidebar .
$(document).ready(function () {
    let toggleBtn = document.querySelector("#CollapsedSidebar");
    let CollapsedSidebar = localStorage.getItem('CollapsedSidebar');
    // Function for add CollapsedSidebar.
    const addCollapsedSidebar = () => {
        document.body.classList.add('sidebar-collapse');
        toggleBtn.checked = true;
        localStorage.setItem('CollapsedSidebar', 'add');
    }
    // Function for remove CollapsedSidebar.
    const removeCollapsedSidebar = () => {
        document.body.classList.remove('sidebar-collapse');
        toggleBtn.checked = false;
        localStorage.setItem('CollapsedSidebar', 'remove');
    }
    if (CollapsedSidebar === 'add') {
        addCollapsedSidebar();
    }
    toggleBtn.addEventListener("change", function () {
        let CollapsedSidebar = localStorage.getItem('CollapsedSidebar');
        if (CollapsedSidebar == 'remove') {
            addCollapsedSidebar();
        } else {
            removeCollapsedSidebar();
        }
    });
});

//Dark-mode and light-mode.
$(document).ready(function () {
    // Dark mode and light mode toggle
    let toggleBtn = document.querySelector("#toggle-btn");
    let darkMode = localStorage.getItem('dark-mode');
    // Function for enabling darkmode
    const enableDarkMode = () => {
        toggleBtn.classList.replace('fa-sun', 'fa-moon');
        document.body.classList.add('dark-mode');
        localStorage.setItem('dark-mode', 'enabled');
    }
    // Function foe disabling darkmode
    const disableDarkMode = () => {
        toggleBtn.classList.replace('fa-moon', 'fa-sun');
        document.body.classList.remove('dark-mode');
        localStorage.setItem('dark-mode', 'disabled');
    }
    if (darkMode === 'disabled') {
        disableDarkMode();
    }
    toggleBtn.onclick = (e) => {
        let darkMode = localStorage.getItem('dark-mode');
        if (darkMode == 'disabled') {
            enableDarkMode();
        } else {
            disableDarkMode();
        }
    }
});