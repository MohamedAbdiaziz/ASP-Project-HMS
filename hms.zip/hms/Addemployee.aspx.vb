﻿Imports System.Data.SqlClient
Imports System.Data

Public Class Addemployee
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Adm\Hospital\Hospital\Hospital\App_Data\Hms.mdf;Integrated Security=True")
    Dim cmd As New SqlCommand

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd.Connection = conn
        cmd.CommandText = CommandType.Text
        cmd.CommandText = "insert into employees values('" + name.Text + "', 
        '" + tellno.Text + "', '" + address.Text + "', '" + age.Text + "', '" + gender.Text + "', 
        '" + job_title.Text + "', '" + salary.Text + "',  '" + reg_date.Text + "')"
        conn.Open()
        cmd.ExecuteNonQuery()
        MsgBox("Data inserted Successfully")
        name.Text = ""
        tellno.Text = ""
        address.Text = ""
        age.Text = ""
        gender.Text = ""
        job_title.Text = ""
        salary.Text = ""
        skills.Text = ""
        reg_date.Text = ""
        Response.Redirect("Employees.aspx")
        conn.Close()

    End Sub
End Class