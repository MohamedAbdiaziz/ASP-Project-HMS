﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Addpatients
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Adm\Hospital\Hospital\Hospital\App_Data\Hms.mdf;Integrated Security=True")
    Dim cmd As New SqlCommand

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub save_Click(sender As Object, e As EventArgs) Handles save.Click
        cmd.Connection = conn
        cmd.CommandText = CommandType.Text
        cmd.CommandText = "insert into patient(name,tellno,address,Age,gender,Reg_fee,created_at) values('" + patient_name.Text + "', '" + tellno.Text + "', '" + address.Text + "', 
        '" + age.Text + "', '" + gender.Text + "', '" + reg_fees.Text + "', '" + reg_date.Text + "')"
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        MsgBox("Data inserted Successfully")
        patient_name.Text = ""
        tellno.Text = ""
        address.Text = ""
        age.Text = ""
        gender.Text = ""
        reg_fees.Text = ""
        reg_date.Text = ""
        Response.Redirect("Patients.aspx")
    End Sub
End Class