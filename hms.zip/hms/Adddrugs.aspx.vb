﻿Imports System.Data.SqlClient
Imports System.Data

Public Class Adddrugs
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Adm\Hospital\Hospital\Hospital\App_Data\Hms.mdf;Integrated Security=True")
    Dim cmd As New SqlCommand

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd.Connection = conn
        cmd.CommandText = CommandType.Text
        cmd.CommandText = "insert into drugs(name,issue_date,expire_date,country,qty,price,created_at) values('" + drug_name.Text + "', 
        '" + issue_date.Text + "', '" + expire_date.Text + "', '" + country.Text + "', 
        '" + qty.Text + "', '" + price.Text + "', '" + reg_date.Text + "')"
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        MsgBox("Data inserted Successfully")
        drug_name.Text = ""
        qty.Text = ""
        issue_date.Text = ""
        expire_date.Text = ""
        country.Text = ""
        price.Text = ""
        reg_date.Text = ""
        Response.Redirect("Drugs.aspx")
    End Sub
End Class